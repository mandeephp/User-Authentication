
from django.conf.urls import url,include
from django.contrib import admin

from . import views

urlpatterns = [
    url(r'^$',views.index,name='index'),
    url(r'^orders/register/$',views.register_user,name='register'),
    url(r'^orders/login/$',views.login1,name='login'),
    url(r'^register_success/$', views.register_success,name='register_success'),
    url(r'^confirm/(?P<activation_key>\w+)/$', views.register_confirm,name='register_confirm'),
    #url(r'^display/?$',views.display,name='display'),
]
